#include "MyLibrary.h"

// Insertion operator for vectors operator<<()
ostream &operator<<(ostream &os, const vector<string> &v) {
  os << "vector: { "; 
  for (auto element : v) {
    os << element << " ";
  }
  os << "}";
  return os;
}

#include <ArduinoSTL.h>

using namespace std; 

ostream &operator<<(ostream &os, const vector<string> &v);
